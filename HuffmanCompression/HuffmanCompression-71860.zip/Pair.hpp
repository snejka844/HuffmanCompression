#pragma once
#include <iostream>

template <typename FirstType=char, typename SecondType = std::size_t>
struct Pair {

public:

	FirstType firstArgument;
	SecondType secondArgument;

	//constructor with parameters
	Pair(const FirstType &firstArgument = FirstType(), const SecondType &secondType=SecondType()):firstArgument(firstArgument),secondArgument(secondArgument){}

	//Copy constructor
	Pair(const Pair<FirstType, SecondType> &other);

	//Operator =
	Pair<FirstType, SecondType> &operator=(const Pair<FirstType, SecondType> &other);

	//This approach is the most permissive approach to declaring a templated friend function of a templated structure. 
	//This will work for all cases where you want to explicitly pass an instance of structure Pair to operator<<().
	template<typename FriendFirstType, typename FriendSecondType>
	friend std::ostream &operator<<(std::ostream &out, const Pair<FriendFirstType, FriendSecondType> &src);

private:
	void copy(const FirstType &firstArgument, const SecondType &secondArgument);

};

template<typename FirstType, typename SecondType>
inline Pair<FirstType, SecondType>::Pair(const Pair<FirstType, SecondType>& other)
{
	this->copy(other.firstArgument, other.secondArgument);
}

template<typename FirstType, typename SecondType>
inline Pair<FirstType, SecondType>& Pair<FirstType, SecondType>::operator=(const Pair<FirstType, SecondType>& other)
{
	// TODO: operator=
	if (this != &other) {

		this->copy(other.firstArgument, other.secondArgument);
	}
	return *this;
}

template<typename FirstType, typename SecondType>
inline void Pair<FirstType, SecondType>::copy(const FirstType & firstArgument, const SecondType & secondArgument)
{
	this->firstArgument = firstArgument;
	this->secondArgument = secondArgument;
}

template<typename FriendFirstType, typename FriendSecondType>
inline std::ostream & operator<<(std::ostream & out, const Pair<FriendFirstType, FriendSecondType>& src)
{
	//Is it necessary to be inline?????

	// TODO: operator<<() for Pair
	out << src.firstArgument << " " << src.secondArgument;
	return out;
}
