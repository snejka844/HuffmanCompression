#pragma once
#include <iostream>

template <typename Type>
class Vector
{
private:
	Type *conteiner;
	std::size_t currentSize;
	std::size_t capacity;
	const std::size_t defaultValue = 8;

	void resize();
	void copy(const Type *conteiner, const std::size_t &currentSize, const std::size_t &capacity);
	void destroy();

public:

	Vector();
	Vector(const Type *conteiner, const int &size, const int &capacity);
	Vector(const Vector<Type> &other);
	~Vector();

	Vector<Type> &operator=(const Vector<Type> &other);

	//Capacity
	int size() const;
	bool empty() const;

	//Element access
	Type &operator[](const int &index);
	const Type &operator[](const int &index) const;

	Type &at(const int &index);
	const Type &at(const int &index) const;

	Type &front();
	const Type &front() const;

	Type &back();
	const Type &back() const;

	//Modifiers
	void push_back(const Type &value);
	void pop_back();

};

template<typename Type>
inline void Vector<Type>::resize()
{
	int newCapacity = 2 * this->capacity;
	Type *tmpContainer = new Type[newCapacity];
	for (size_t i = 0; i < this->capacity; ++i) {
		tmpContainer[i] = this->conteiner[i];
	}
	delete[] this->conteiner;

	this->conteiner = tmpContainer;
	this->capacity = newCapacity;

}

template <typename Type>
inline void Vector<Type>::copy(const Type *conteiner, const std::size_t &currentSize, const std::size_t &capacity) {
	this->conteiner = new Type[capacity];
	this->currentSize = currentSize;
	this->capacity = capacity;

	for (std::size_t i = 0; i < currentSize; ++i) {
		this->conteiner[i] = conteiner[i];
	}
}

template <typename Type>
inline void Vector<Type>::destroy() {
	delete[] this->conteiner;
}

template <typename Type>
inline Vector<Type>::Vector() {
	this->conteiner = new Type[this->defaultValue];
	this->currentSize = 0;
	this->capacity = this->defaultValue;
}

template <typename Type>
inline Vector<Type>::~Vector() {
	destroy();
}

template <typename Type>
inline Vector<Type>::Vector(const Type *conteiner, const int &size, const int &capacity) {
	this->copy(conteiner, size, capacity);
}

template <typename Type>
inline Vector<Type>::Vector(const Vector<Type> &other) {
	this->copy(other.conteiner, other.currentSize, other.capacity);

}

template <typename Type>
inline Vector<Type>& Vector<Type>::operator=(const Vector<Type> &other) {

	//TODO: operator=
	if (this != &other) {
		this->destroy();
		this->copy(other.conteiner, other.currentSize, other.capacity);
	}
	return *this;
}

template<typename Type>
inline int Vector<Type>::size() const
{
	return this->currentSize;
}

template<typename Type>
inline bool Vector<Type>::empty() const
{
	return this->currentSize==0;
}

template<typename Type>
inline Type & Vector<Type>::operator[](const int & index)
{
	// TODO: operator[]
	if (index < 0 || index >= this->currentSize) {
		throw "NoSuchIndex";
	}
	return this->conteiner[index];
}

template<typename Type>
inline const Type & Vector<Type>::operator[](const int & index) const
{
	// TODO: function[]
	if (index < 0 || index >= this->currentSize) {
		throw "NoSuchIndexException";
	}
	return this->conteiner[index];
	
}

template<typename Type>
inline Type & Vector<Type>::at(const int & index)
{
	// TODO: function at()
	if (index < 0 || index >= this->currentSize) {
		throw "NoSuchIndexException";
	}
	return this->conteiner[index];
}

template<typename Type>
inline const Type & Vector<Type>::at(const int & index) const
{
	// TODO: function at()
	if (index < 0 || index >= this->currentSize) {
		throw "NoSuchIndexException";
	}
	return this->conteiner[index];
}

template<typename Type>
inline Type & Vector<Type>::front()
{
	if (this->currentSize == 0) {
		throw "VectorIsEmptyException";
	}
	return this->conteiner[0];
}

template<typename Type>
inline const Type & Vector<Type>::front() const
{
	if (this->currentSize == 0) {
		throw "VectorIsEmptyException";
	}
	return this->conteiner[0];
}

template<typename Type>
inline Type & Vector<Type>::back()
{
	if (this->currentSize == 0) {
		throw "VectorIsEmptyException";
	}
	return this->conteiner[currentSize - 1];
}

template<typename Type>
inline const Type & Vector<Type>::back() const
{
	if (this->currentSize == 0) {
		throw "VectorIsEmptyException";
	}
	return this->conteiner[currentSize - 1];
}

template<typename Type>
inline void Vector<Type>::push_back(const Type & value)
{
	if (this->currentSize == this->capacity) {
		this->resize();
	}
	this->conteiner[this->currentSize++] = value;
}

template<typename Type>
inline void Vector<Type>::pop_back()
{
	if (this->currentSize == 0 || this->currentSize == -1) {
		throw "VectorIsEmptyException";
	}
	--(this->currentSize);
}
