//Snejana Stoyanova 71860
#include <iostream>
#include "Vector.hpp"
#include "Node.h"
#include "MinHeap.hpp"
#include <fstream>
#include "HuffmanTree.h"
#include "Algorithm.h"
#include "FileUniter.h"
int main() {

	/*
	std::ifstream file;
	char symbol = file.peek();
	if (symbol = file.get() == char(247))
		std::cout << symbol;
	std::cout << char(248);
	*/
	mainProgram();
	system ("pause");
}